const post = 3000;
const delimiter = '?';
const outputFunctionName = 'echo';
//<? ?>
const ejsConfig = {
	delimiter,
	outputFunctionName
};
const express = require("express");
const ejs = require("ejs");
const bodyParser = require('body-parser');
const app = express();
const session = require('express-session');
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const ios = require('socket.io-express-session');
const fs = require('fs');

let $_DATA = { server: 0 };

var requires = {
	app,
	io
};
const sessionMiddleware = session({
	secret: "keyboard cat",
	resave: false
});
app.use(sessionMiddleware);
io.use(ios(sessionMiddleware));
//app.set("view engine", "ejs");
app.use(bodyParser.json({
	limit: "50mb"
}));
app.use(bodyParser.urlencoded({
	limit: "50mb",
	extended: false
}));

function isFileSync(filepath){
	let flag = true;
	try {
		fs.accessSync(filepath, fs.constants.F_OK);
	} catch (e){
		flag = false;
	}
	return flag;
}

function lastSplit(str, splitChar){
	var split = str.split(splitChar);
	return split[split.length-1];
}

function homeEjs(dir, res, data){
	if(isFileSync("./App/www/" + dir + "index.ejs")){
		ejs.renderFile('./App/www/' + dir + 'index.ejs', data, ejsConfig, function(err, str){
			if(err) console.error(err);
			res.send(str);
		});
	} else if(isFileSync("./App/www/" + dir + "main.ejs")){
		ejs.renderFile('./App/www/' + dir + 'main.ejs', data, ejsConfig, function(err, str){
			if(err) console.error(err);
			res.send(str);
		});
	} else if(isFileSync("./App/www/" + dir + "home.ejs")){
		ejs.renderFile('./App/www/' + dir + 'home.ejs', data, ejsConfig, function(err, str){
			if(err) console.error(err);
			res.send(str);
		});
	} else {
		ejs.renderFile('./App/data/error.ejs', data, ejsConfig, function(err, str){
			if(err) console.error(err);
			res.send(str);
		});
	}
}

app.all('/:param(*)', function(req, res){
	var param = req.params.param;
	var file = param.replace(/\.\.\//gi, '').replace(/.php/gi, '.ejs');
	$_DATA.server++;
	var data = {
		require,
		url: param,
		res,
		req,
		session: req.session,
		$_fs_DIRNAME: `./App/www/${file}`,
		$_GET: req.query,
		$_POST: req.body,
		$_DATA
	};
	Object.assign(data, requires);
	function server(commonData){
		data.$_COMMON_DATA = commonData;
		if(param == ''){
			homeEjs('', res, data);
		} else {
			if(file.endsWith('/')){
				if(fs.existsSync("./App/www/" + (file.substring(0, file.length-1)))){
					homeEjs(file, res, data);
				} else {
					ejs.renderFile('./App/data/error.ejs', data, ejsConfig, function(err, str){
						if(err) console.error(err);
						res.send(str);
					});
				}
			} else {
				if(fs.existsSync("./App/www/" + file)){
					homeEjs(file+'/', res, data);
				} else if(file.endsWith('.ejs')){
					if(!isFileSync("./App/www/" + file)){
						ejs.renderFile('./App/data/error.ejs', data, ejsConfig, function(err, str){
							if(err) console.error(err);
							res.send(str);
						});
					} else {
						ejs.renderFile('./App/www/' + file, data, ejsConfig, function(err, str){
							if(err) console.error(err);
							res.send(str);
						});
					}
				} else {
					if(!isFileSync("./App/www/" + file)){
						ejs.renderFile('./App/data/error.ejs', data, ejsConfig, function(err, str){
							if(err) console.error(err);
							res.send(str);
						});
					} else {
						res.send(fs.readFileSync('./App/www/' + file));
					}
				}
			}
		}
	}
	if(isFileSync("./App/data/common.ejs")){
		ejs.renderFile('./App/data/common.ejs', data, ejsConfig, function(err, str){
			if(err) console.error(err);
			server(str);
		});
	} else {
		server({});
	}
});
server.listen(post, '0.0.0.0');